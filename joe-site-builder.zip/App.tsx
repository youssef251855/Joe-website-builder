import React from 'react';
import { HashRouter, Routes, Route, Outlet, Navigate } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import HomePage from './pages/HomePage';
import BuilderPage from './pages/BuilderPage';
import MySitesPage from './pages/MySitesPage';
import ExplorePage from './pages/ExplorePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Layout from './components/Layout';

// A layout for routes that require authentication
const ProtectedLayout: React.FC = () => {
  const { currentUser } = useAuth();
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  return <Layout />;
};

// A layout for routes that should only be accessed when logged out
const PublicLayout: React.FC = () => {
  const { currentUser } = useAuth();
  if (currentUser) {
    return <Navigate to="/builder" replace />;
  }
  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
};


function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <HashRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            
            {/* Public routes for login/register */}
            <Route element={<PublicLayout />}>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
            </Route>

            {/* Protected routes for the main app */}
            <Route element={<ProtectedLayout />}>
              <Route path="/builder" element={<BuilderPage />} />
              <Route path="/builder/:siteId" element={<BuilderPage />} />
              <Route path="/mysites" element={<MySitesPage />} />
              <Route path="/explore" element={<ExplorePage />} />
            </Route>

          </Routes>
        </HashRouter>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;