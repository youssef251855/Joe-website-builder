import React from 'react';
import { useLocalization } from '../hooks/useLocalization';

interface DeployModalProps {
    htmlContent: string;
    onClose: () => void;
}

const DeployModal: React.FC<DeployModalProps> = ({ htmlContent, onClose }) => {
    const { t } = useLocalization();

    const handleDownloadHtml = () => {
        const blob = new Blob([htmlContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'index.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
            aria-labelledby="deploy-title"
        >
            <div 
                className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col"
                onClick={(e) => e.stopPropagation()}
            >
                <header className="p-6 border-b flex justify-between items-center">
                    <h2 id="deploy-title" className="text-2xl font-bold text-gray-800">{t('deploy_title')}</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800" aria-label={t('close')}>
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </header>
                
                <main className="p-6 overflow-y-auto space-y-6">
                    <p className="text-gray-600">{t('deploy_intro')}</p>
                    
                    <section>
                        <h3 className="font-bold text-lg text-gray-700">{t('step_1_title')}</h3>
                        <p className="text-sm text-gray-600 mb-3">{t('step_1_desc')}</p>
                        <button 
                            onClick={handleDownloadHtml}
                            className="bg-green-600 text-white font-bold py-2 px-4 rounded-md hover:bg-green-700 transition-colors"
                        >
                            {t('download_html')}
                        </button>
                    </section>

                     <section>
                        <h3 className="font-bold text-lg text-gray-700">{t('step_2_title')}</h3>
                        <p className="text-sm text-gray-600 mb-3">{t('step_2_desc')}</p>
                        <a
                          href="https://app.netlify.com/drop"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-block bg-cyan-600 text-white font-bold py-2 px-4 rounded-md hover:bg-cyan-700 transition-colors"
                        >
                          {t('open_netlify')}
                        </a>
                    </section>
                    
                    <section>
                        <h3 className="font-bold text-lg text-gray-700">{t('step_3_title')}</h3>
                        <div className="space-y-1 text-sm text-gray-600">
                           <p>{t('step_3_desc')}</p>
                           <p className="font-semibold pt-2">{t('deploy_complete')}</p>
                        </div>
                    </section>
                </main>

                <footer className="p-4 bg-gray-50 border-t flex justify-end">
                    <button onClick={onClose} className="bg-indigo-600 text-white font-bold py-2 px-6 rounded-md hover:bg-indigo-700 transition-colors">
                        {t('close')}
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default DeployModal;