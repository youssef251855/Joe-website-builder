import React from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

const Header: React.FC = () => {
    const { t } = useLocalization();
    const { toggleLanguage } = useLanguage();
    const { currentUser, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const linkClasses = ({ isActive }: { isActive: boolean }) =>
        `text-base font-medium transition-colors duration-300 ${isActive ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'}`;

    return (
        <header className="bg-white/50 backdrop-blur-lg p-4 shadow-sm sticky top-0 z-20 w-full">
            <div className="container mx-auto flex justify-between items-center">
                <Link to={currentUser ? "/builder" : "/"} className="text-2xl font-bold text-gray-800">
                    {t('app_title')}
                </Link>
                
                {currentUser ? (
                    <div className="flex items-center gap-6">
                        <nav className="hidden md:flex items-center gap-6">
                            <NavLink to="/builder" className={linkClasses}>
                                {t('builder')}
                            </NavLink>
                            <NavLink to="/mysites" className={linkClasses}>
                                {t('my_sites')}
                            </NavLink>
                            <NavLink to="/explore" className={linkClasses}>
                                {t('explore')}
                            </NavLink>
                        </nav>
                        <div className="flex items-center gap-4">
                             <span className="text-sm text-gray-600 hidden sm:block">{currentUser.email}</span>
                            <button
                                onClick={handleLogout}
                                className="text-gray-600 font-semibold py-2 px-4 rounded-md hover:bg-gray-100 transition-colors duration-300"
                            >
                                {t('logout')}
                            </button>
                            <button
                                onClick={toggleLanguage}
                                className="bg-indigo-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-indigo-600 transition-colors duration-300"
                                aria-label={`Switch to ${t('toggle_language')}`}
                            >
                                {t('toggle_language')}
                            </button>
                        </div>
                    </div>
                ) : (
                     <div className="flex items-center gap-4">
                        <NavLink to="/login" className={linkClasses}>
                            {t('login')}
                        </NavLink>
                        <NavLink to="/register" className="bg-indigo-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-indigo-600 transition-colors duration-300">
                            {t('register')}
                        </NavLink>
                         <button
                            onClick={toggleLanguage}
                            className="bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded-md hover:bg-gray-300 transition-colors duration-300"
                            aria-label={`Switch to ${t('toggle_language')}`}
                        >
                            {t('toggle_language')}
                        </button>
                    </div>
                )}
            </div>
        </header>
    );
};

export default Header;