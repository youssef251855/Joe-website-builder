
import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';

const Layout: React.FC = () => {
    return (
        <div className="flex flex-col h-screen bg-gray-100">
            <Header />
            <main className="flex-1 overflow-y-auto">
                 <Outlet />
            </main>
        </div>
    );
};

export default Layout;
