
import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';

interface SitePreviewProps {
  htmlContent: string;
}

type Device = 'desktop' | 'tablet' | 'mobile';

const SitePreview: React.FC<SitePreviewProps> = ({ htmlContent }) => {
  const { t } = useLocalization();
  const [device, setDevice] = useState<Device>('desktop');

  const deviceWidths: { [key in Device]: string } = {
    desktop: 'w-full',
    tablet: 'w-[768px]',
    mobile: 'w-[375px]',
  };

  const DeviceIcon: React.FC<{
    type: Device,
    current: Device,
    onClick: (type: Device) => void,
    children: React.ReactNode
  }> = ({ type, current, onClick, children }) => (
    <button
      onClick={() => onClick(type)}
      title={t(type)}
      className={`p-2 rounded-md transition-colors ${current === type ? 'bg-indigo-500 text-white' : 'text-gray-500 hover:bg-gray-200 hover:text-gray-800'}`}
    >
      {children}
    </button>
  );

  return (
    <div className="flex-1 flex flex-col bg-gray-200 rounded-lg shadow-inner overflow-hidden">
      <div className="bg-gray-50 p-2 flex items-center justify-between text-white border-b border-gray-300">
        <div className="flex items-center gap-2">
            <div className="flex space-x-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
        </div>
        <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-lg">
            <DeviceIcon type="desktop" current={device} onClick={setDevice}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" /></svg>
            </DeviceIcon>
            <DeviceIcon type="tablet" current={device} onClick={setDevice}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 2a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V4a2 2 0 00-2-2H5zm0 2h10v12H5V4z" clipRule="evenodd" /></svg>
            </DeviceIcon>
            <DeviceIcon type="mobile" current={device} onClick={setDevice}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4a2 2 0 00-2-2H6zm0 2h8v12H6V4z" clipRule="evenodd" /></svg>
            </DeviceIcon>
        </div>
        <div className="w-16"></div> {/* Spacer */}
      </div>
      <div className="flex-1 p-4 bg-gray-200 flex justify-center items-start overflow-auto">
        <div className={`shadow-xl transition-all duration-300 ease-in-out ${deviceWidths[device]}`}>
          <iframe
            srcDoc={htmlContent}
            title="Website Preview"
            className="w-full h-[600px] border-none"
            sandbox="allow-scripts allow-same-origin"
          />
        </div>
      </div>
    </div>
  );
};

export default SitePreview;
