
export interface ExploreSite {
  title: { en: string; ar: string; };
  description: { en: string; ar: string; };
  html: string;
}

export const exploreSites: ExploreSite[] = [
  {
    title: { en: 'Photography Portfolio', ar: 'ملف مصور فوتوغرافي' },
    description: { en: 'A sleek, modern portfolio for a professional photographer.', ar: 'ملف أعمال أنيق وعصري لمصور محترف.' },
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alex Doe Photography</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>:lang(ar) { direction: rtl; }</style>
</head>
<body class="bg-black text-white font-sans">
    <div id="content-en" lang="en">
        <nav class="p-6 flex justify-between items-center">
            <h1 class="text-3xl font-bold tracking-wider">ALEX DOE</h1>
            <div>
                <a href="#gallery" class="mx-4 hover:text-gray-400">Gallery</a>
                <a href="#about" class="mx-4 hover:text-gray-400">About</a>
                <button onclick="toggleLang()" class="ml-4 bg-gray-800 py-2 px-4 rounded hover:bg-gray-700">العربية</button>
            </div>
        </nav>
        <main class="container mx-auto px-6 py-12">
            <section id="gallery" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <img src="https://picsum.photos/800/600?random=1" alt="photo 1" class="w-full h-full object-cover rounded"/>
                <img src="https://picsum.photos/800/600?random=2" alt="photo 2" class="w-full h-full object-cover rounded"/>
                <img src="https://picsum.photos/800/600?random=3" alt="photo 3" class="w-full h-full object-cover rounded"/>
                <img src="https://picsum.photos/800/600?random=4" alt="photo 4" class="w-full h-full object-cover rounded col-span-2"/>
                 <img src="https://picsum.photos/800/600?random=5" alt="photo 5" class="w-full h-full object-cover rounded"/>
            </section>
        </main>
    </div>
    <div id="content-ar" lang="ar" style="display: none;">
        <nav class="p-6 flex justify-between items-center">
            <h1 class="text-3xl font-bold tracking-wider">أليكس دو</h1>
            <div>
                <a href="#gallery-ar" class="mx-4 hover:text-gray-400">المعرض</a>
                <a href="#about-ar" class="mx-4 hover:text-gray-400">من أنا</a>
                <button onclick="toggleLang()" class="ml-4 bg-gray-800 py-2 px-4 rounded hover:bg-gray-700">English</button>
            </div>
        </nav>
        <main class="container mx-auto px-6 py-12">
             <section id="gallery-ar" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <img src="https://picsum.photos/800/600?random=1" alt="صورة 1" class="w-full h-full object-cover rounded"/>
                <img src="https://picsum.photos/800/600?random=2" alt="صورة 2" class="w-full h-full object-cover rounded"/>
                <img src="https://picsum.photos/800/600?random=3" alt="صورة 3" class="w-full h-full object-cover rounded"/>
                <img src="https://picsum.photos/800/600?random=4" alt="صورة 4" class="w-full h-full object-cover rounded col-span-2"/>
                 <img src="https://picsum.photos/800/600?random=5" alt="صورة 5" class="w-full h-full object-cover rounded"/>
            </section>
        </main>
    </div>
    <script>
        function toggleLang() {
            const en = document.getElementById('content-en'), ar = document.getElementById('content-ar');
            const isEn = en.style.display !== 'none';
            en.style.display = isEn ? 'none' : 'block';
            ar.style.display = isEn ? 'block' : 'none';
            document.documentElement.lang = isEn ? 'ar' : 'en';
        }
    </script>
</body>
</html>`,
  },
  {
    title: { en: 'Coffee Shop', ar: 'مقهى' },
    description: { en: 'A warm and inviting landing page for a local coffee shop.', ar: 'صفحة هبوط دافئة وجذابة لمقهى محلي.' },
    html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Daily Grind</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>:lang(ar) { direction: rtl; }</style>
</head>
<body class="bg-yellow-50 font-serif">
    <div id="content-en" lang="en">
        <header class="text-center py-20 bg-cover" style="background-image: url('https://picsum.photos/1200/400?random=6')">
            <div class="bg-black bg-opacity-50 py-10">
                <h1 class="text-6xl font-bold text-white">The Daily Grind</h1>
                <p class="text-xl text-yellow-100 mt-2">Your daily dose of happiness.</p>
            </div>
        </header>
        <main class="container mx-auto p-8 text-center">
            <h2 class="text-3xl font-bold text-yellow-900 mb-4">Our Menu</h2>
            <p class="text-lg text-gray-700">Freshly brewed coffee, artisanal pastries, and a cozy atmosphere.</p>
            <button onclick="toggleLang()" class="mt-8 bg-yellow-800 text-white py-3 px-6 rounded-full hover:bg-yellow-900">الاطلاع باللغة العربية</button>
        </main>
    </div>
    <div id="content-ar" lang="ar" style="display: none;">
        <header class="text-center py-20 bg-cover" style="background-image: url('https://picsum.photos/1200/400?random=6')">
            <div class="bg-black bg-opacity-50 py-10">
                <h1 class="text-6xl font-bold text-white">القهوة اليومية</h1>
                <p class="text-xl text-yellow-100 mt-2">جرعتك اليومية من السعادة.</p>
            </div>
        </header>
        <main class="container mx-auto p-8 text-center">
            <h2 class="text-3xl font-bold text-yellow-900 mb-4">قائمتنا</h2>
            <p class="text-lg text-gray-700">قهوة طازجة، معجنات فنية، وأجواء مريحة.</p>
            <button onclick="toggleLang()" class="mt-8 bg-yellow-800 text-white py-3 px-6 rounded-full hover:bg-yellow-900">View in English</button>
        </main>
    </div>
    <script>
        function toggleLang() {
            const en = document.getElementById('content-en'), ar = document.getElementById('content-ar');
            const isEn = en.style.display !== 'none';
            en.style.display = isEn ? 'none' : 'block';
            ar.style.display = isEn ? 'block' : 'none';
            document.documentElement.lang = isEn ? 'ar' : 'en';
        }
    </script>
</body>
</html>`,
  },
];
