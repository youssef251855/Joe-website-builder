import { Translations } from '../types';

export const translations: Translations = {
  // Homepage
  main_title: {
    en: 'Build a Website with a Single Prompt',
    ar: 'أنشئ موقعًا إلكترونيًا بوصف نصي واحد',
  },
  main_subtitle: {
    en: 'Describe your idea, and our AI will generate a complete, ready-to-publish website in seconds. Modern, simple, and incredibly fast.',
    ar: 'صف فكرتك، وسيقوم الذكاء الاصطناعي بإنشاء موقع ويب كامل وجاهز للنشر في ثوانٍ. حديث وبسيط وسريع بشكل لا يصدق.',
  },
  start_now: {
    en: 'Start Now',
    ar: 'ابدأ الآن',
  },
  // Header
  builder: { en: 'Builder', ar: 'المنشئ' },
  my_sites: { en: 'My Sites', ar: 'مواقعي' },
  explore: { en: 'Explore', ar: 'استكشف' },
  login: { en: 'Login', ar: 'تسجيل الدخول' },
  register: { en: 'Register', ar: 'التسجيل' },
  logout: { en: 'Logout', ar: 'تسجيل الخروج' },

  // Builder Page
  app_title: {
    en: 'Joe Site Builder',
    ar: 'Joe Site Builder',
  },
  prompt_placeholder: {
    en: 'e.g., "Create a personal portfolio for a web developer" or "A landing page for a new coffee shop".',
    ar: 'مثال: "أنشئ صفحة شخصية لمطور ويب" أو "صفحة هبوط لمقهى جديد".',
  },
  generate_site: {
    en: 'Generate Site',
    ar: 'أنشئ الموقع',
  },
  generating: {
    en: 'Generating...',
    ar: 'جاري الإنشاء...',
  },
  site_preview: {
    en: 'Site Preview',
    ar: 'معاينة الموقع',
  },
  language: {
    en: 'Language',
    ar: 'اللغة',
  },
  toggle_language: {
    en: 'AR',
    ar: 'EN',
  },
  ai_assistant: { en: 'AI Assistant', ar: 'مساعد ذكي' },
  ai_assistant_tooltip: { en: 'Get help from AI to improve your prompt', ar: 'احصل على مساعدة من الذكاء الاصطناعي لتحسين وصفك' },

  // Site Preview
  desktop: { en: 'Desktop', ar: 'سطح المكتب' },
  tablet: { en: 'Tablet', ar: 'جهاز لوحي' },
  mobile: { en: 'Mobile', ar: 'هاتف محمول' },

  // My Sites Page
  my_sites_title: { en: 'My Websites', ar: 'مواقع الويب الخاصة بي' },
  my_sites_empty: { en: 'You haven\'t created any sites yet. Start building!', ar: 'لم تقم بإنشاء أي مواقع بعد. ابدأ البناء!' },
  edit: { en: 'Edit', ar: 'تعديل' },
  delete: { en: 'Delete', ar: 'حذف' },
  delete_confirm: { en: 'Are you sure you want to delete this site?', ar: 'هل أنت متأكد أنك تريد حذف هذا الموقع؟' },
  created_at: { en: 'Created:', ar: 'تم الإنشاء:' },

  // Explore Page
  explore_title: { en: 'Explore Examples', ar: 'استكشف الأمثلة' },
  explore_subtitle: { en: 'Get inspired by what you can create with Joe Site Builder.', ar: 'احصل على الإلهام مما يمكنك إنشاؤه باستخدام Joe Site Builder.' },
  view_site: { en: 'View Site', ar: 'عرض الموقع' },

  // Auth Pages
  email_label: { en: 'Email Address', ar: 'البريد الإلكتروني' },
  password_label: { en: 'Password', ar: 'كلمة المرور' },
  confirm_password_label: { en: 'Confirm Password', ar: 'تأكيد كلمة المرور' },
  login_title: { en: 'Log in to your account', ar: 'سجل الدخول إلى حسابك' },
  register_title: { en: 'Create a new account', ar: 'أنشئ حسابًا جديدًا' },
  no_account: { en: "Don't have an account?", ar: 'ليس لديك حساب؟' },
  have_account: { en: 'Already have an account?', ar: 'لديك حساب بالفعل؟' },
  login_failed: { en: 'Login failed. Please check your credentials.', ar: 'فشل تسجيل الدخول. يرجى التحقق من بياناتك.' },
  register_failed: { en: 'Registration failed. This email may already be in use.', ar: 'فشل التسجيل. قد يكون هذا البريد الإلكتروني مستخدمًا بالفعل.' },
  password_mismatch: { en: 'Passwords do not match.', ar: 'كلمات المرور غير متطابقة.'},
  password_length: { en: 'Password must be at least 6 characters long.', ar: 'يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.' },
  
  // Deploy Modal
  deploy_guide: { en: 'Deploy Guide', ar: 'دليل النشر' },
  deploy_title: { en: 'Deploy with Netlify Drop', ar: 'النشر باستخدام Netlify Drop' },
  deploy_intro: { en: 'The easiest way to get your site live! Netlify Drop allows you to publish your website in seconds with a simple drag-and-drop.', ar: 'أسهل طريقة لنشر موقعك على الإنترنت! تتيح لك Netlify Drop نشر موقع الويب الخاص بك في ثوانٍ بمجرد السحب والإفلات.' },
  close: { en: 'Close', ar: 'إغلاق' },
  step_1_title: { en: 'Step 1: Download Your File', ar: 'الخطوة 1: قم بتنزيل ملفك' },
  step_1_desc: { en: 'Click the button below to download the `index.html` file for your website to your computer.', ar: 'انقر فوق الزر أدناه لتنزيل ملف `index.html` الخاص بموقعك على جهاز الكمبيوتر الخاص بك.' },
  download_html: { en: 'Download index.html', ar: 'تنزيل index.html' },
  step_2_title: { en: 'Step 2: Open Netlify Drop', ar: 'الخطوة 2: افتح Netlify Drop' },
  step_2_desc: { en: 'Click the link below to open the Netlify Drop page in a new browser tab. You may need to sign up for a free account.', ar: 'انقر على الرابط أدناه لفتح صفحة Netlify Drop في علامة تبويب متصفح جديدة. قد تحتاج إلى التسجيل للحصول على حساب مجاني.' },
  open_netlify: { en: 'Open Netlify Drop', ar: 'افتح Netlify Drop' },
  step_3_title: { en: 'Step 3: Drag & Drop', ar: 'الخطوة 3: اسحب وأفلت' },
  step_3_desc: { en: 'Simply drag the `index.html` file you just downloaded from your computer and drop it onto the Netlify Drop page in your browser.', ar: 'ببساطة، اسحب ملف `index.html` الذي قمت بتنزيله للتو من جهاز الكمبيوتر الخاص بك وأفلته في صفحة Netlify Drop في متصفحك.' },
  deploy_complete: { en: 'That\'s it! Netlify will instantly generate a live URL for your new website. You can customize the site name in your Netlify dashboard.', ar: 'هذا كل شيء! ستقوم Netlify على الفور بإنشاء رابط مباشر لموقعك الجديد. يمكنك تخصيص اسم الموقع من لوحة تحكم Netlify.' },
};