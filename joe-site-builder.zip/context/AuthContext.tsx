import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { User, AuthCredentials } from '../types';

interface AuthContextType {
  currentUser: User | null;
  login: (credentials: AuthCredentials) => boolean;
  register: (credentials: AuthCredentials) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// In a real app, this would be a secure backend. For this simulation, we use localStorage.
// This is NOT secure for production use.
const USERS_KEY = 'siteBuilderUsers';
const CURRENT_USER_KEY = 'siteBuilderCurrentUser';

const getUsers = (): User[] => {
    const usersJson = localStorage.getItem(USERS_KEY);
    return usersJson ? JSON.parse(usersJson) : [];
};

const saveUsers = (users: User[]) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const userJson = localStorage.getItem(CURRENT_USER_KEY);
    return userJson ? JSON.parse(userJson) : null;
  });

  const register = (credentials: AuthCredentials): boolean => {
    const users = getUsers();
    const existingUser = users.find(user => user.email === credentials.email);
    if (existingUser) {
      return false; // User already exists
    }
    const newUser: User = { email: credentials.email, password: credentials.password };
    users.push(newUser);
    saveUsers(users);
    setCurrentUser(newUser);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
    return true;
  };

  const login = (credentials: AuthCredentials): boolean => {
    const users = getUsers();
    const user = users.find(u => u.email === credentials.email && u.password === credentials.password);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(CURRENT_USER_KEY);
  };

  return (
    <AuthContext.Provider value={{ currentUser, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};