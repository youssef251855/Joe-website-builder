
import { useLanguage } from '../context/LanguageContext';
import { translations } from '../constants/translations';
import { Language } from '../types';

export const useLocalization = () => {
  const { language } = useLanguage();

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return { t, language };
};
