import React, { useState, useEffect, useCallback } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { generateWebsiteHtml, getPromptSuggestion } from '../services/geminiService';
import { demoSiteHtml } from '../constants/demoSiteHtml';
import SitePreview from '../components/SitePreview';
import Spinner from '../components/Spinner';
import DeployModal from '../components/DeployModal';
import { Site } from '../types';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const BuilderPage: React.FC = () => {
  const { t, language } = useLocalization();
  const { siteId } = useParams<{ siteId: string }>();
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [prompt, setPrompt] = useState('');
  const [generatedHtml, setGeneratedHtml] = useState(demoSiteHtml);
  const [isLoading, setIsLoading] = useState(false);
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);
  const [currentSite, setCurrentSite] = useState<Site | null>(null);
  
  const SITES_KEY = `userSites_${currentUser?.email}`;

  const getSites = useCallback((): Site[] => {
    if (!currentUser) return [];
    const sitesJson = localStorage.getItem(SITES_KEY);
    return sitesJson ? JSON.parse(sitesJson) : [];
  }, [currentUser, SITES_KEY]);

  useEffect(() => {
    if (siteId) {
      const sites = getSites();
      const siteToEdit = sites.find(s => s.id === siteId);
      if (siteToEdit) {
        setCurrentSite(siteToEdit);
        setPrompt(siteToEdit.prompt);
        setGeneratedHtml(siteToEdit.html);
      }
    }
  }, [siteId, getSites]);

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const saveSite = (siteToSave: Site) => {
    if (!currentUser) return;
    const sites = getSites();
    const existingIndex = sites.findIndex(s => s.id === siteToSave.id);
    if (existingIndex > -1) {
      sites[existingIndex] = siteToSave;
    } else {
      sites.unshift(siteToSave);
    }
    localStorage.setItem(SITES_KEY, JSON.stringify(sites));
  };
  
  const handleGenerate = async () => {
    if (!prompt || isLoading || !currentUser) return;
    setIsLoading(true);
    try {
      const html = await generateWebsiteHtml(prompt);
      setGeneratedHtml(html);
      const newSite: Site = {
        id: currentSite?.id || crypto.randomUUID(),
        prompt,
        html,
        createdAt: new Date().toISOString(),
      };
      saveSite(newSite);
      setCurrentSite(newSite);
      if (!siteId) {
        navigate(`/builder/${newSite.id}`, { replace: true });
      }
    } catch (error) {
      alert((error as Error).message);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleAiAssistant = async () => {
      setIsLoading(true);
      try {
          const suggestion = await getPromptSuggestion(prompt);
          setPrompt(suggestion);
      } catch (error) {
          alert((error as Error).message);
      } finally {
          setIsLoading(false);
      }
  };
  
  return (
    <>
    <div className="flex-1 flex flex-col md:flex-row gap-4 p-4 overflow-hidden">
        {/* Left Panel: Controls */}
        <div className="w-full md:w-1/3 flex flex-col gap-4">
          <div className="bg-white rounded-lg shadow p-4 flex-1 flex flex-col">
            <div className="flex justify-between items-center mb-2">
              <label htmlFor="prompt" className="font-semibold text-gray-700">{t('prompt_placeholder')}</label>
              <button onClick={handleAiAssistant} disabled={isLoading} title={t('ai_assistant_tooltip')} className="flex items-center gap-1.5 text-sm text-indigo-600 font-semibold hover:text-indigo-800 disabled:opacity-50">
                <span role="img" aria-label="sparkles">✨</span>
                {t('ai_assistant')}
              </button>
            </div>
            <textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={t('prompt_placeholder')}
              className="w-full flex-1 p-3 border border-gray-300 rounded-md resize-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
          </div>
          <div className="bg-white rounded-lg shadow p-4 space-y-4">
             <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full flex justify-center items-center gap-2 bg-indigo-600 text-white font-bold py-3 px-4 rounded-md hover:bg-indigo-700 disabled:bg-indigo-300 transition-colors"
            >
              {isLoading && <Spinner />}
              {isLoading ? t('generating') : t('generate_site')}
            </button>
             <button
              onClick={() => setIsDeployModalOpen(true)}
              disabled={!currentSite}
              className="w-full flex justify-center items-center gap-2 bg-green-600 text-white font-bold py-3 px-4 rounded-md hover:bg-green-700 disabled:bg-green-300 transition-colors"
            >
              {t('deploy_guide')}
            </button>
          </div>
        </div>
        
        {/* Right Panel: Preview */}
        <div className="w-full md:w-2/3 flex flex-col">
          <SitePreview htmlContent={generatedHtml} />
        </div>
    </div>
    {isDeployModalOpen && currentSite && (
        <DeployModal 
            htmlContent={currentSite.html} 
            onClose={() => setIsDeployModalOpen(false)} 
        />
    )}
    </>
  );
};

export default BuilderPage;