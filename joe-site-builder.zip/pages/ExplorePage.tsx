
import React from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { exploreSites } from '../constants/exploreSites';

const ExplorePage: React.FC = () => {
    const { t, language } = useLocalization();

    const handleViewSite = (html: string) => {
        const newWindow = window.open();
        if (newWindow) {
            newWindow.document.write(html);
            newWindow.document.close();
        }
    };

    return (
        <div className="container mx-auto p-4 md:p-8">
            <div className="text-center mb-10">
                <h1 className="text-3xl md:text-4xl font-bold text-gray-800">{t('explore_title')}</h1>
                <p className="mt-2 text-lg text-gray-600">{t('explore_subtitle')}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {exploreSites.map((site, index) => {
                    return (
                        <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col group">
                             <div className="p-6 flex-1">
                                <h2 className="text-xl font-bold text-gray-800 mb-2">{site.title[language]}</h2>
                                <p className="text-gray-600">{site.description[language]}</p>
                            </div>
                            <div className="p-4 bg-gray-50 border-t">
                                <button
                                    onClick={() => handleViewSite(site.html)}
                                    className="inline-block bg-indigo-600 text-white font-semibold py-2 px-5 rounded-md hover:bg-indigo-700 transition-all duration-300 group-hover:shadow-lg"
                                >
                                    {t('view_site')}
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default ExplorePage;