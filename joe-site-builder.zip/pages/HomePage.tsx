import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';
import Header from '../components/Header'; // Import Header

const HomePage: React.FC = () => {
  const { t, language } = useLocalization();

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);


  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight">
              {t('main_title')}
            </h1>
            <p className="mt-6 text-lg md:text-xl text-gray-600">
              {t('main_subtitle')}
            </p>
            <Link
              to="/register"
              className="mt-10 inline-block bg-indigo-600 text-white font-bold text-lg py-4 px-10 rounded-lg shadow-lg hover:bg-indigo-700 transition-transform transform hover:scale-105 duration-300"
            >
              {t('start_now')}
            </Link>
          </div>
      </div>
    </div>
  );
};

export default HomePage;