import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';
import { Site } from '../types';
import { useAuth } from '../context/AuthContext';

const MySitesPage: React.FC = () => {
    const { t } = useLocalization();
    const [sites, setSites] = useState<Site[]>([]);
    const { currentUser } = useAuth();

    const SITES_KEY = `userSites_${currentUser?.email}`;

    const getSites = useCallback(() => {
        if (!currentUser) return;
        const sitesJson = localStorage.getItem(SITES_KEY);
        if (sitesJson) {
            setSites(JSON.parse(sitesJson));
        }
    }, [currentUser, SITES_KEY]);
    
    useEffect(() => {
        getSites();
    }, [getSites]);

    const handleDelete = (siteId: string) => {
        if (window.confirm(t('delete_confirm'))) {
            const updatedSites = sites.filter(s => s.id !== siteId);
            setSites(updatedSites);
            localStorage.setItem(SITES_KEY, JSON.stringify(updatedSites));
        }
    };

    return (
        <div className="container mx-auto p-4 md:p-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">{t('my_sites_title')}</h1>
            
            {sites.length === 0 ? (
                <div className="text-center py-16 px-6 bg-white rounded-lg shadow">
                    <p className="text-xl text-gray-600">{t('my_sites_empty')}</p>
                    <Link
                        to="/builder"
                        className="mt-6 inline-block bg-indigo-600 text-white font-bold py-3 px-8 rounded-lg shadow-md hover:bg-indigo-700 transition-transform transform hover:scale-105"
                    >
                        {t('start_now')}
                    </Link>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {sites.map(site => (
                        <div key={site.id} className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
                            <div className="p-5 flex-1">
                                <p className="text-sm text-gray-500 mb-2">
                                    {t('created_at')} {new Date(site.createdAt).toLocaleDateString()}
                                </p>
                                <p className="font-semibold text-gray-700 truncate" title={site.prompt}>
                                    {site.prompt}
                                </p>
                            </div>
                            <div className="p-3 bg-gray-50 border-t flex items-center justify-end gap-2">
                                <Link
                                    to={`/builder/${site.id}`}
                                    className="text-sm bg-indigo-100 text-indigo-700 font-semibold py-2 px-4 rounded-md hover:bg-indigo-200 transition-colors"
                                >
                                    {t('edit')}
                                </Link>
                                <button
                                    onClick={() => handleDelete(site.id)}
                                    className="text-sm bg-red-100 text-red-700 font-semibold py-2 px-4 rounded-md hover:bg-red-200 transition-colors"
                                >
                                    {t('delete')}
                                </button>
                            </div>
                        </div>
                       )
                    )}
                </div>
            )}
        </div>
    );
};

export default MySitesPage;