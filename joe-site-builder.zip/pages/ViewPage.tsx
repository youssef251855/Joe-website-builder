// This page is no longer used as the publishing system has been updated.
// Users are now guided to deploy their sites to Firebase Hosting.
import React from 'react';

const ViewPage: React.FC = () => {
    return null;
};

export default ViewPage;
