
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const systemInstruction = `You are an AI assistant that functions as an expert web developer. 
Your task is to generate a complete, single-file, responsive HTML website based on a user's description.
The generated HTML must use Tailwind CSS for styling, linked via the official CDN (<script src="https://cdn.tailwindcss.com"></script>) in the <head>.
The entire output must be a single, valid HTML document.
All content, including text and image placeholders (using https://picsum.photos), should be in both English and Arabic.
You must include a simple JavaScript toggle function to switch between the English and Arabic content. The Arabic version should have RTL text direction.
The generated code must be a complete and valid HTML document, starting with <!DOCTYPE html> and ending with </html>.
Do not wrap the HTML code in markdown backticks.`;

export const generateWebsiteHtml = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });

    let htmlContent = response.text;

    // Clean up potential markdown formatting
    if (htmlContent.startsWith('```html')) {
      htmlContent = htmlContent.substring(7);
    }
    if (htmlContent.endsWith('```')) {
      htmlContent = htmlContent.substring(0, htmlContent.length - 3);
    }

    return htmlContent.trim();
  } catch (error) {
    console.error("Error generating website:", error);
    throw new Error("Failed to generate website. Please try again.");
  }
};

export const getPromptSuggestion = async (currentPrompt: string): Promise<string> => {
  try {
    const suggestionPrompt = currentPrompt 
      ? `Improve this user prompt for generating a website. Make it more descriptive and specific about design elements, sections, and content. Return only the improved prompt. User prompt: "${currentPrompt}"`
      : `Suggest a creative and detailed prompt for generating a website. For example, a portfolio for a graphic designer or a landing page for a new mobile app. Return only the prompt.`;
      
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: suggestionPrompt,
      config: {
        temperature: 0.8,
      },
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error generating prompt suggestion:", error);
    throw new Error("Failed to get a suggestion. Please try again.");
  }
}
