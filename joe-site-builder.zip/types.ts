
export type Language = 'en' | 'ar';

export type Translations = {
  [key: string]: {
    [lang in Language]: string;
  };
};

export interface Site {
  id: string;
  prompt: string;
  html: string;
  createdAt: string;
}

// FIX: Define and export User and AuthCredentials types.
export interface AuthCredentials {
  email: string;
  password: string;
}

export type User = AuthCredentials;